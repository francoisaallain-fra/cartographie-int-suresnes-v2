# Suresnes — test de sources cartographiques du 19 octobre 2026

Objectif : tester concrètement six besoins (fond photo, PLU, transports, santé/scolarité, offres de bureaux, commerces de quartier), à l’échelle de la commune INSEE 92073. Le résultat est un instantané de données publiques, sans mise à jour automatique, sans diagnostic de faisabilité et sans certification de vacance.

## Résultats

- Fond IGN BD ORTHO : flux WMTS testé, photographies aériennes 2024 à 20 cm selon la notice départementale du 21 septembre 2026. Ce sont des photographies aériennes, pas des images de satellite.
- PLU : 55 polygones valides, 21 libellés ; document `92073_PLU_20240626`, publié le 15 janvier 2025, indiqué en vigueur sur le GPU.
- Transports IDFM : 4 enregistrements dans la commune, regroupés en 3 stations par `id_ref_zdc` ; Suresnes–Mont-Valérien (L/U), Suresnes–Longchamp (T2), Belvédère (T2). Pas de métro dans cet extrait communal.
- Éducation nationale : 30 établissements ouverts, dont 23 écoles, 5 collèges et 2 lycées, sur 33 entrées communales. Deux structures médico-sociales et un service administratif exclus. Le point de l’école Marianne Picard, hors commune dans la source, est remplacé par le géocodage BAN du 28 rue Pagès ; coordonnées originales conservées.
- Santé FINESS : 13 établissements de soins sélectionnés parmi 81 établissements sanitaires, sociaux et médico-sociaux. Catégories 365, 109, 292, 124, 603, 617, 146 : soins pluridisciplinaires, SSR, psychiatrie, centres et maison de santé, soins non programmés et dialyse. Échantillon de catégorie explicite, pas un classement validé des « grandes » aménités.
- Quartier : 18 boulangeries OSM et 13 pharmacies FINESS. 13 pharmacies OSM récupérées pour contrôle mais non additionnées. La pharmacie des Chênes a une précision FINESS à la rue, signalée dans sa fiche.
- Bureaux : 10 cartes d’annonces Suresnes observées, dont 3 sans adresse. Échantillon des 5 premières offres avec adresse explicite dans l’ordre de la source ; pages détaillées testées et adresses géocodées BAN. Toutes déclarent une disponibilité immédiate. La vacance physique ou juridique demeure inconnue. Deux autres annonces avec adresse n’ont pas été incluses dans cet échantillon.

## Données et traçabilité

`raw/` contient les réponses originales et, pour chaque réponse, un fichier `.meta.json` avec URL, date UTC, code HTTP, taille et empreinte SHA-256. Le CSV national FINESS (~48 Mo) est conservé localement, mais n’est pas redistribué dans la carte ou l’archive de livraison. Certaines réponses sont compressées gzip malgré leur extension JSON ; `prepare.py` le détecte.

`processed/` contient les couches GeoJSON en longitude/latitude WGS84, `sources.json`, `quality.json`, les candidats broker et le manifeste des extractions. Les couches publiées ne reprennent ni contacts personnels, ni photos, ni descriptions commerciales intégrales.

Les données ouvertes sont sous Licence Ouverte pour IGN/IDFM/Éducation/FINESS/BAN, ODbL pour OSM. Aucune licence ouverte n’est identifiée pour BNP Paribas Real Estate : cet essai ponctuel et limité ne vaut pas autorisation de collecte industrielle ou de redistribution d’un catalogue complet. Aucun compte, captcha ou restriction d’accès n’a été contourné.

## Géographie et 500 mètres

- Limite de Suresnes issue de `geo.api.gouv.fr`, contrôles d’appartenance avec Shapely.
- FINESS : jointure `structureet` / `geolocalisation` par identifiant géographique, département 92 + commune 073, conversion Lambert-93 vers WGS84 avec PyProj.
- Les 55 polygones PLU sont conservés sans simplification. Leur union couvre 99,5368 % du contour communal de l’autre source ; superpositions de 64,86 m². Ces différences ne sont pas réparées silencieusement. Aucune précision cadastrale n’est certifiée.
- Les points bureaux sont des localisants d’adresse BAN. Le 72–74 rue Rouget-de-Lisle est représenté au numéro 74. Le point du 13 boulevard Henri-Sellier diffère de 94 m du point broker : l’adresse BAN est utilisée, et cet écart est consigné.
- Distances et cercles calculés avec `pyproj.Geod(ellps='WGS84')`, seuil inclusif <= 500 m, à vol d’oiseau. Le cercle est échantillonné tous les 2 degrés d’azimut. Il ne décrit pas un parcours ou un temps piéton.
- Seules les aménités de Suresnes sont collectées : les équipements voisins manquent dans la portion du cercle hors commune. Une absence de point ne prouve pas l’absence d’équipement.

## Reproduire l’instantané

Python 3.12 ; dépendances épinglées dans `requirements.txt`.

```sh
python3 -m venv .venv
.venv/bin/pip install -r requirements.txt
.venv/bin/python scripts/probe.py
.venv/bin/python scripts/collect.py
.venv/bin/python scripts/broker.py
.venv/bin/python scripts/prepare.py
```

Exécuter depuis ce dossier. Les fichiers déjà présents sont réutilisés : ils constituent une preuve datée. Pour une nouvelle extraction, créer un dossier daté distinct, mettre à jour les constantes et réexaminer la sélection de catégories, le correctif de l’école, les adresses et les contrôles d’effectifs. Les assertions de `prepare.py` sont les critères de recette de cet instantané, pas des effectifs attendus pour toujours. Le scraper s’arrête à cinq fiches et espace les appels au broker ; toute extension récurrente exige un cadrage fournisseur.

La carte est dans `../../sites/carte-couches-suresnes/dist/`. Serveur local : `python3 -m http.server 8768 --bind 127.0.0.1 --directory ../../sites/carte-couches-suresnes/dist`.

## Contrôles et reprise

`reports/browser-qa.json` : test Chrome des cinq interrupteurs, des cinq sélections de bureau, du clic sur repère, du retour à la ville, des sources et du mobile. Captures PNG dans `reports/`. Les annulations de tuiles `ERR_ABORTED` lors d’un changement rapide de vue sont distinctes d’une erreur de chargement ; les tuiles de la vue initiale ont chargé sans échec.

En cas d’échec du fond photo, le site conserve les points et propose « Réessayer ». En cas d’échec du fichier de données, il affiche une erreur de chargement explicite. « Vue ville » ou « Revenir à toute la ville » quitte le filtre spatial.

Interlocuteur : François Allain. Responsable de maintenance à désigner avant industrialisation. La validation de la vacance requiert le broker, le propriétaire ou un état locatif daté ; le PLU doit être instruit avec ses pièces complètes avant une décision opérationnelle.
