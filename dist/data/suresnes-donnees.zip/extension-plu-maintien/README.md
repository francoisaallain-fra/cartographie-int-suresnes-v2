# Suresnes · Maintien des surfaces de bureau (PLU)

Extraction du 29 octobre 2026. Le Géoportail de l'urbanisme indique le document `92073_PLU_20240626`, version 4, publié le 15 janvier 2025, « en vigueur ». Le producteur est la Ville de Suresnes.

## Sources officielles

- [Fiche GPU du document](https://www.geoportail-urbanisme.gouv.fr/document/by-id/64ef58d064a2d45604223108ff089d2d)
- [Plan de zonage de juin 2024](https://data.geopf.fr/annexes/gpu/documents/DU_92073/64ef58d064a2d45604223108ff089d2d/92073_reglement_graphique_20240626.pdf), légende « Maintien des surfaces de bureau » en tirets rouges
- [Règlement de juin 2024](https://data.geopf.fr/annexes/gpu/documents/DU_92073/64ef58d064a2d45604223108ff089d2d/92073_reglement_20240626.pdf#page=9), dispositions générales, article 14, page imprimée 8
- [API Carto IGN, prescriptions surfaciques](https://apicarto.ign.fr/api/gpu/prescription-surf?partition=DU_92073) : 603 objets pour ce PLU, dont cinq avec `txt=SUR_BUREAU` et `libelle=Maintien des surfaces de bureau`.

Les réponses et deux PDF sont préservés dans `sources/`. `extract.py` produit `sites/carte-couches-suresnes/dist/data/plu-maintien-bureaux.geojson` et un journal de qualité à partir de la géométrie officielle, sans retracé manuel. Les cinq polygones sont valides, entièrement dans la commune, pour environ 36,6 ha au total (surface SIG indicative, pas une surface de plancher).

## Lecture de la règle

Dans les secteurs rouges, l'article 14 encadre le changement de destination des surfaces **déjà affectées au bureau**. Le bureau peut être transformé vers certaines sous-destinations listées : commerces et services précisés, certains équipements, industrie et activités tertiaires. Le logement ou l'hébergement n'est admis que s'il est minoritaire dans la surface de plancher du projet et intrinsèquement lié à l'activité principale du bâtiment. Les surfaces existantes de moins de 100 m² sont exemptées de cette disposition.

Il ne s'agit donc ni d'une interdiction absolue de toute transformation, ni d'une preuve que chaque parcelle du périmètre contient des bureaux. Une étude d'actif doit vérifier l'état autorisé, les surfaces, le zonage et les autres règles applicables. Le tracé numérique est un outil de repérage ; la pièce graphique et le règlement du PLU font référence pour une décision.

## Reproduction

Exécuter `recherches/suresnes-donnees-2026-10-19/.venv/bin/python3 recherches/suresnes-maintien-bureaux-2026-10-29/extract.py` depuis la racine du projet. `shapely` et `pyproj` sont nécessaires. Un changement de document ou de nombre d'objets arrête le script afin de forcer un nouvel examen.
